# POOWorkshop (C# / .NET 8)

Taller práctico de Programación Orientada a Objetos (FASE 2).

## Requisitos
- .NET 8 SDK
- VS Code o Visual Studio

## Ejecutar
```
cd src/POOWorkshop
dotnet restore
dotnet run
```
