namespace POOWorkshop.Domain.Interfaces;

public interface IPayable
{
    decimal CalculatePayment();
}
