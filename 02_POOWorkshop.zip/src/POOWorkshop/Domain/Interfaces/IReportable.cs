namespace POOWorkshop.Domain.Interfaces;

public interface IReportable
{
    string BuildReport();
}
