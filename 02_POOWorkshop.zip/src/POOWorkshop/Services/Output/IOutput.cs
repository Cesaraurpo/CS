namespace POOWorkshop.Services.Output;

public interface IOutput
{
    void WriteLine(string text);
}
